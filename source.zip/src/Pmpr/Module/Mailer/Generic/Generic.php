<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663038660df5c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\x67\145\156\145\x72\x69\x63" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto cuoqqgaygogsmmic; } Engine::symcgieuakksimmu(); cuoqqgaygogsmmic: } }
