<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f112f4dd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\x67\145\x6e\145\x72\x69\x63" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto qiaqsassksqiuyae; } Engine::symcgieuakksimmu(); qiaqsassksqiuyae: } }
