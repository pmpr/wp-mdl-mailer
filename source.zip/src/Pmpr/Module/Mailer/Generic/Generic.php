<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630aefab3cca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\x67\x65\156\145\x72\x69\143" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto cgewcsueoyaeikgm; } Engine::symcgieuakksimmu(); cgewcsueoyaeikgm: } }
