<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630b03a25626             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\147\x65\x6e\145\162\151\x63" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto cgewcsueoyaeikgm; } Engine::symcgieuakksimmu(); cgewcsueoyaeikgm: } }
