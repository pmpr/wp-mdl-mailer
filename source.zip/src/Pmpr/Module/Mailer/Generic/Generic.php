<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a8a6b6a27             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\147\145\156\145\x72\x69\143" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto qiaqsassksqiuyae; } Engine::symcgieuakksimmu(); qiaqsassksqiuyae: } }
