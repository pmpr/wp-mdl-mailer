<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66303997ed875             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\x67\145\x6e\145\162\x69\143" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto cuoqqgaygogsmmic; } Engine::symcgieuakksimmu(); cuoqqgaygogsmmic: } }
