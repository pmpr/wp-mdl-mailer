<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630faf770d42             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\x67\145\x6e\145\x72\x69\143" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto igymseewwyiocoug; } Engine::symcgieuakksimmu(); igymseewwyiocoug: } }
