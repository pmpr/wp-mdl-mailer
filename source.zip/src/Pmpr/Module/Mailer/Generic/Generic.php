<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400db0d0ab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\147\145\156\x65\162\x69\x63" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto cecuyayqoioasumi; } Engine::symcgieuakksimmu(); cecuyayqoioasumi: } }
