<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66302bd6945eb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\x67\145\x6e\x65\162\151\143" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto cuoqqgaygogsmmic; } Engine::symcgieuakksimmu(); cuoqqgaygogsmmic: } }
