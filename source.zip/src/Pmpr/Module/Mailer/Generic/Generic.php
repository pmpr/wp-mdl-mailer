<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630290f59842             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\x67\145\x6e\145\162\151\x63" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto cuoqqgaygogsmmic; } Engine::symcgieuakksimmu(); cuoqqgaygogsmmic: } }
