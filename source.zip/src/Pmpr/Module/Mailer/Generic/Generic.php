<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687081132000             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\x67\145\156\x65\162\151\x63" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto cecuyayqoioasumi; } Engine::symcgieuakksimmu(); cecuyayqoioasumi: } }
