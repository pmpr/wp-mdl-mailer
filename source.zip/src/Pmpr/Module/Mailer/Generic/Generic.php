<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56da8616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\147\145\156\145\x72\x69\x63" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto qiaqsassksqiuyae; } Engine::symcgieuakksimmu(); qiaqsassksqiuyae: } }
