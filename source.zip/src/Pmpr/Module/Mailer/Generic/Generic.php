<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630a1fca5cad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; class Generic extends Common { public function mameiwsayuyquoeq() { if (!("\x67\x65\156\x65\x72\x69\143" === Setting::symcgieuakksimmu()->guseqygmqcgeyigi())) { goto cgewcsueoyaeikgm; } Engine::symcgieuakksimmu(); cgewcsueoyaeikgm: } }
