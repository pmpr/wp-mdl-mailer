<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630b03a25626             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; use Pmpr\Module\Mailer\Container; abstract class Common extends Container { }
