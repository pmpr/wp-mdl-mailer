<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec26c9ce3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; use Pmpr\Module\Mailer\Container; abstract class Common extends Container { }
