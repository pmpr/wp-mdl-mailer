<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66302bd6945eb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; use Pmpr\Module\Mailer\Container; abstract class Common extends Container { }
