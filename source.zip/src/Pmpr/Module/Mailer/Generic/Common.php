<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630aefab3cca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Generic; use Pmpr\Module\Mailer\Container; abstract class Common extends Container { }
