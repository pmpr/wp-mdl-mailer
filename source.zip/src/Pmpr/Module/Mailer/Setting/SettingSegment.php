<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687081132000             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment; class SettingSegment extends Segment { public function ikcgmcycisiccyuc() { $this->setting = Setting::symcgieuakksimmu(); } public function guseqygmqcgeyigi() : string { return $this->eiwcuqigayigimak()->guseqygmqcgeyigi(); } public function omimwscgequgiaue() : bool { return !empty($this->eiwcuqigayigimak()->giiuwsmyumqwwiyq(Setting::aoaqugseeqkemumi)) && !empty($this->eiwcuqigayigimak()->giiuwsmyumqwwiyq(Setting::acwacoiwicmigmom)) && !empty($this->eiwcuqigayigimak()->giiuwsmyumqwwiyq(Setting::ycwieuigecimyggq)) && !empty($this->eiwcuqigayigimak()->giiuwsmyumqwwiyq(Setting::emawkokeeikckeym)); } }
