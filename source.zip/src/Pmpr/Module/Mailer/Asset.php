<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             661e41b7e8cec             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\144\x6d\151\x6e\137\151\x6e\x69\x74", [$this, "\145\x6e\x71\165\x65\x75\x65"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\164\145\163\x74\x2d\145\155\141\x69\x6c", $eygsasmqycagyayw->get("\164\145\163\x74\56\152\x73"))->ayuciigykaswwqeo("\152\161\165\145\x72\171")); $eygsasmqycagyayw->ikqyiskqaaymscgw("\x61\x6a\141\170", ["\163\145\x6e\x64\137\x65\155\x61\x69\154" => Ajax::ykiigwasoeagkiuq]); } }
