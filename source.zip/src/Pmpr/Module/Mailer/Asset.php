<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             662d7732930d0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; class Asset extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\141\x64\155\x69\156\137\x69\x6e\x69\164", [$this, "\x65\x6e\161\x75\x65\165\145"]); } public function enqueue() { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->ayeieigcckcmsikq($eygsasmqycagyayw->owygwqwawqoiusis("\x74\145\163\x74\x2d\x65\155\x61\151\154", $eygsasmqycagyayw->get("\164\x65\163\164\x2e\152\163"))->ayuciigykaswwqeo("\152\161\x75\145\162\x79")); $eygsasmqycagyayw->ikqyiskqaaymscgw("\141\x6a\x61\x78", ["\163\145\156\x64\137\x65\155\141\151\154" => Ajax::ykiigwasoeagkiuq]); } }
