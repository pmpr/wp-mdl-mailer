<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660695df535c5             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\ComponentInitiator; class Mailer extends ComponentInitiator { public function register() { $this->gkieogwukagigisy(__DIR__, [self::qescuiwgsyuikume => static function () { return __("\x4d\141\x69\x6c\x65\162", PR__MDL__MAILER); }, self::wuowaiyouwecckaw => false]); } public function mameiwsayuyquoeq() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto cuykwgmswkskqkyi; } Setting::symcgieuakksimmu(); cuykwgmswkskqkyi: Ajax::symcgieuakksimmu(); Asset::symcgieuakksimmu(); Engine::symcgieuakksimmu(); } }
