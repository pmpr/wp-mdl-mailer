<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630b546006c4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\141\165\x74\150\157\x72\151\x7a\145\x64"; const oiugqmossekuqeia = "\157\141\x75\x74\x68\137\147\x72\x61\156\x74"; const ewmyoqeiikakqqmk = "\141\165\164\x68\157\x72\151\172\x61\x74\x69\x6f\156\137\x75\x72\x69"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
