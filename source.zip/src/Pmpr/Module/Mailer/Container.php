<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb5f112f4dd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\141\x75\164\x68\157\162\x69\172\145\144"; const oiugqmossekuqeia = "\x6f\x61\x75\x74\x68\137\x67\x72\141\156\164"; const ewmyoqeiikakqqmk = "\141\x75\x74\x68\x6f\162\151\172\x61\x74\151\157\x6e\137\165\162\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
