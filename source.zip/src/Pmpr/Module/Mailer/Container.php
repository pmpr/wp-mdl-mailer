<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6687081132000             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\141\165\x74\150\x6f\162\x69\x7a\x65\x64"; const oiugqmossekuqeia = "\157\x61\165\x74\x68\x5f\x67\x72\141\x6e\x74"; const ewmyoqeiikakqqmk = "\x61\165\164\150\x6f\x72\x69\x7a\141\x74\151\157\156\x5f\x75\x72\x69"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
