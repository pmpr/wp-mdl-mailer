<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec26c9ce3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\x61\x75\x74\150\157\162\x69\x7a\x65\x64"; const oiugqmossekuqeia = "\157\141\x75\164\x68\137\x67\162\x61\156\164"; const ewmyoqeiikakqqmk = "\141\165\164\150\x6f\x72\x69\x7a\x61\x74\x69\157\x6e\x5f\x75\x72\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
