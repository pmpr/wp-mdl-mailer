<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663336a4245b2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\x61\165\164\x68\x6f\x72\151\172\x65\x64"; const oiugqmossekuqeia = "\x6f\x61\x75\164\x68\x5f\x67\x72\141\x6e\164"; const ewmyoqeiikakqqmk = "\141\165\164\x68\157\x72\151\172\x61\x74\151\157\x6e\x5f\x75\162\x69"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
