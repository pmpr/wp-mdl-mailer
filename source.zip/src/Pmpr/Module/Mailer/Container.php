<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663038660df5c             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\x61\x75\164\150\x6f\162\151\x7a\x65\x64"; const oiugqmossekuqeia = "\157\141\165\164\150\x5f\147\x72\141\x6e\x74"; const ewmyoqeiikakqqmk = "\141\x75\164\150\x6f\162\151\172\x61\x74\x69\157\156\137\165\x72\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
