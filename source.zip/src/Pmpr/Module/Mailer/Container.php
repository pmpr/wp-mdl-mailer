<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66303997ed875             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\141\165\x74\x68\157\162\x69\172\145\144"; const oiugqmossekuqeia = "\x6f\141\165\x74\x68\137\147\x72\x61\156\164"; const ewmyoqeiikakqqmk = "\141\x75\x74\x68\x6f\162\x69\x7a\x61\164\x69\157\x6e\x5f\165\x72\x69"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
