<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663035f8da4f0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const oiugqmossekuqeia = "\157\141\165\164\x68\137\147\162\x61\156\164"; const ewmyoqeiikakqqmk = "\141\165\x74\150\x6f\162\151\172\x61\164\151\157\x6e\x5f\165\x72\x69"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
