<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663045694a993             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\141\x75\x74\x68\157\x72\151\172\x65\144"; const oiugqmossekuqeia = "\157\x61\x75\x74\150\x5f\147\x72\x61\x6e\164"; const ewmyoqeiikakqqmk = "\x61\x75\164\150\x6f\162\x69\172\x61\x74\151\157\156\137\165\x72\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
