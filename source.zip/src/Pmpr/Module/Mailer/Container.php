<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630b03a25626             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\x61\165\164\x68\157\162\151\x7a\145\x64"; const oiugqmossekuqeia = "\x6f\141\x75\164\x68\137\147\x72\x61\x6e\164"; const ewmyoqeiikakqqmk = "\141\x75\164\150\157\x72\151\x7a\141\x74\151\x6f\x6e\137\x75\162\x69"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
