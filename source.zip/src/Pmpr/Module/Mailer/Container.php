<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             663031b2b6a13             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const oiugqmossekuqeia = "\157\141\x75\x74\150\x5f\147\x72\x61\156\x74"; const ewmyoqeiikakqqmk = "\x61\165\x74\x68\157\162\151\172\141\164\x69\x6f\156\137\x75\162\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
