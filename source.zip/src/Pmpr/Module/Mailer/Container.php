<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630a1fca5cad             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\141\165\164\x68\x6f\x72\151\172\145\144"; const oiugqmossekuqeia = "\x6f\141\165\x74\x68\x5f\x67\x72\141\156\x74"; const ewmyoqeiikakqqmk = "\x61\x75\164\x68\x6f\x72\x69\172\141\164\x69\x6f\156\x5f\165\162\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
