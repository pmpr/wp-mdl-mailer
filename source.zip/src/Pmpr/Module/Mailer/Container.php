<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66cb56da8616d             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\141\165\164\150\x6f\x72\x69\172\145\144"; const oiugqmossekuqeia = "\157\141\x75\x74\150\x5f\147\162\x61\156\164"; const ewmyoqeiikakqqmk = "\x61\165\164\x68\157\x72\x69\172\x61\164\x69\x6f\x6e\x5f\165\162\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
