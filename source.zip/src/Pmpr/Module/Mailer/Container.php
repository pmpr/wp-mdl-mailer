<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630b75d6b5ce             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\x61\x75\164\x68\x6f\162\151\172\145\x64"; const oiugqmossekuqeia = "\x6f\141\165\164\x68\137\147\x72\141\156\x74"; const ewmyoqeiikakqqmk = "\141\x75\164\x68\157\x72\x69\172\x61\164\151\157\156\137\165\x72\x69"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
