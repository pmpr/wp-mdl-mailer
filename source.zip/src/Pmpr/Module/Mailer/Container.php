<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630290f59842             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const oiugqmossekuqeia = "\157\141\165\164\x68\137\x67\x72\141\156\x74"; const ewmyoqeiikakqqmk = "\x61\x75\164\150\x6f\162\151\x7a\141\164\x69\157\156\x5f\165\x72\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
