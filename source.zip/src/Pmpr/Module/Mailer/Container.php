<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630aefab3cca             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\x61\x75\164\150\x6f\x72\x69\172\145\x64"; const oiugqmossekuqeia = "\157\141\165\164\150\137\147\162\141\x6e\x74"; const ewmyoqeiikakqqmk = "\141\x75\164\150\x6f\162\151\x7a\x61\164\x69\157\x6e\137\165\x72\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
