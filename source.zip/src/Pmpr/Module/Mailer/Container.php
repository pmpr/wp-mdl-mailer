<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6630faf770d42             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\141\165\x74\150\x6f\162\151\x7a\145\x64"; const oiugqmossekuqeia = "\x6f\x61\165\x74\x68\137\147\x72\x61\x6e\x74"; const ewmyoqeiikakqqmk = "\x61\165\x74\150\x6f\x72\x69\172\141\164\151\157\156\137\165\162\x69"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
