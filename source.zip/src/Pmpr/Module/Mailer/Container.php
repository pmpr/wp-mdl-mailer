<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8a5c9632             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const yckkaiueuoiicisc = "\x61\x75\164\150\157\162\x69\x7a\145\x64"; const oiugqmossekuqeia = "\157\x61\x75\164\150\x5f\x67\x72\x61\156\164"; const ewmyoqeiikakqqmk = "\x61\165\164\150\157\x72\151\172\141\164\x69\x6f\156\x5f\165\x72\x69"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
