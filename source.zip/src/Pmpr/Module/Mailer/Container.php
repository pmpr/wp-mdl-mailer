<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66302bd6945eb             |
    |_______________________________________|
*/
 namespace Pmpr\Module\Mailer; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\Mailer\Setting\Setting; abstract class Container extends BaseClass { const oiugqmossekuqeia = "\x6f\x61\165\x74\150\x5f\x67\162\x61\x6e\164"; const ewmyoqeiikakqqmk = "\141\165\x74\150\157\x72\x69\x7a\x61\164\x69\157\156\137\165\x72\151"; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
